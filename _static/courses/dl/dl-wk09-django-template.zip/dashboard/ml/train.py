"""
การบ้านสัปดาห์ที่ 9 — PyTorch Perceptron Dashboard

นักศึกษาต้องเขียนโค้ดในไฟล์นี้ให้สมบูรณ์ โดยต้องมีฟังก์ชัน:

    def event_stream():
        # generator ที่ yield dict ข้อมูลทีละ epoch แล้ว stream ผ่าน SSE

yield dict ที่มี key ต่อไปนี้ (แต่ละ epoch ระหว่างฝึกสอน):
    {
        "type": "progress",
        "epoch": <int>,
        "loss": <float>,
        "accuracy": <float>,
    }

และเมื่อฝึกสอนเสร็จ yield dict สุดท้าย:
    {
        "type": "done",
        "results": <ผลสรุป เช่น ลิงก์ไปยัง loss_curve.png>,
    }

ข้อกำหนด:
    1. สร้างข้อมูล binary classification (linear separable) ด้วย torch.randn
    2. สร้าง perceptron = nn.Linear(2, 1) + nn.Sigmoid()
    3. Training loop ด้วยมือ: forward -> loss -> backward -> update weights
    4. ทดลอง learning rate 3 ค่า: 0.001, 0.1, 1.0
    5. บันทึก loss curve เป็น PNG ที่ dashboard/static/dashboard/loss_curve.png
       แล้ว return เส้นทางให้เบราว์เซอร์แสดงผล (เช่น "static/dashboard/loss_curve.png")

ดูตัวอย่างโค้ดได้จาก slides wk09.html และ wk09-hw.py
"""

# TODO: เขียนโค้ดการบ้านตรงนี้


def event_stream():
    """
    generator สำหรับ stream ผลการฝึกสอนผ่าน SSE

    ตัวอย่างการใช้งานใน views.train_stream():
        for event in train.event_stream():
            yield ...
    """    # ----- ตัวอย่างโครงสร้าง (นักศึกษาต้องเขียนให้สมบูรณ์) -----

    import torch
    import torch.nn as nn

    # 1. สร้างข้อมูล (linear separable binary classification)
    #    X = torch.randn(200, 2)
    #    y = ((X[:, 0] * 1.5 + X[:, 1] - 0.5) > 0).float().unsqueeze(1)
    X = torch.randn(200, 2)
    y = ((X[:, 0] * 1.5 + X[:, 1] - 0.5) > 0).float().unsqueeze(1)

    # 2. สร้างโมเดล perceptron
    model = nn.Sequential(
        nn.Linear(2, 1),
        nn.Sigmoid(),
    )

    loss_fn = nn.BCELoss()

    # ลอง learning rates ต่าง ๆ
    learning_rates = [0.001, 0.1, 1.0]

    for lr in learning_rates:
        # reset weights ใหม่สำหรับแต่ละ lr
        for layer in model:
            if hasattr(layer, "reset_parameters"):
                layer.reset_parameters()

        for epoch in range(300):
            # 3. training loop ด้วยมือ
            y_hat = model(X)
            loss = loss_fn(y_hat, y)

            loss.backward()

            with torch.no_grad():
                for p in model.parameters():
                    p -= lr * p.grad
                model.zero_grad()

            # คำนวณ accuracy
            acc = ((y_hat > 0.5).float() == y).float().mean().item()

            if epoch % 10 == 0:
                yield {
                    "type": "progress",
                    "epoch": epoch,
                    "loss": loss.item(),
                    "accuracy": acc,
                }

    # 4. บันทึก loss curve (TODO: ปรับให้ครบ — ปัจจุบันยังไม่ได้บันทึกกราฟจริง)
    yield {
        "type": "done",
        "results": "static/dashboard/loss_curve.png",  # TODO: ต้องสร้างไฟล์จริง
    }
