"""
การบ้านสัปดาห์ที่ 13 — Text Generator Dashboard

นักศึกษาต้องเขียนโค้ดในไฟล์นี้ให้สมบูรณ์ โดยต้องมีฟังก์ชัน:

    def event_stream():
        # generator ที่ yield dict ข้อมูลทีละ epoch แล้ว stream ผ่าน SSE

yield dict ที่มี key ต่อไปนี้ (แต่ละ epoch ระหว่างฝึกสอน):
    {
        "type": "progress",
        "epoch": <int>,
        "loss": <float>,
        "sample": <str ข้อความที่ model สร้างขึ้น>,
    }

และเมื่อฝึกสอนเสร็จ yield dict สุดท้าย:
    {
        "type": "done",
        "results": <ผลสรุป เช่น samples.txt หรือ loss_curve.png>,
    }

ข้อกำหนด:
    1. โหลดข้อความจาก data/corpus.txt
    2. สร้าง vocabulary (char-level หรือ word-level)
    3. สร้างโมเดล LSTM (Embedding + LSTM + Linear)
    4. Training loop + สร้างตัวอย่างข้อความทุก 10 epoch
    5. บันทึก samples.txt และ loss_curve.png
       ที่ dashboard/static/dashboard/

ดูตัวอย่างโค้ดได้จาก slides wk13.html
"""

# TODO: เขียนโค้ดการบ้านตรงนี้


def event_stream():
    """
    generator สำหรับ stream ผลการฝึกสอนผ่าน SSE
    """
    # ----- ตัวอย่างโครงสร้าง (char-level, นักศึกษาต้องเขียนให้สมบูรณ์) -----

    import torch
    import torch.nn as nn

    # 1. โหลดข้อความ
    #    ตัวอย่าง: ใช้ข้อความสั้น ๆ จำลอง นักศึกษาควรโหลดจาก data/corpus.txt
    text = "the quick brown fox jumps over the lazy dog the quick brown fox"
    text = text * 20  # ทำซ้ำเพื่อให้มีข้อมูลเพียงพอ

    # 2. สร้าง vocabulary
    chars = sorted(set(text))
    char_to_idx = {c: i for i, c in enumerate(chars)}
    idx_to_char = {i: c for c, i in char_to_idx.items()}
    vocab_size = len(chars)

    data = [char_to_idx[c] for c in text]
    seq_length = 50

    # 3. สร้าง training sequences
    X, y = [], []
    for i in range(0, len(data) - seq_length - 1):
        X.append(data[i : i + seq_length])
        y.append(data[i + 1 : i + seq_length + 1])
    X = torch.tensor(X)
    y = torch.tensor(y)

    # 4. โมเดล LSTM
    class TextGenerator(nn.Module):
        def __init__(self, vocab, embed_dim=64, hidden=128):
            super().__init__()
            self.embed = nn.Embedding(vocab, embed_dim)
            self.lstm = nn.LSTM(embed_dim, hidden, batch_first=True)
            self.fc = nn.Linear(hidden, vocab)

        def forward(self, x):
            out = self.embed(x)
            out, _ = self.lstm(out)
            return self.fc(out.reshape(-1, out.size(2)))

    model = TextGenerator(vocab_size)
    loss_fn = nn.CrossEntropyLoss()
    opt = torch.optim.Adam(model.parameters(), lr=0.001)

    # 5. ฟังก์ชันสร้างข้อความ
    def generate(model, start, length=200):
        model.eval()
        with torch.no_grad():
            chars_out = list(start)
            input_x = torch.tensor([char_to_idx[c] for c in start]).unsqueeze(0)
            h, c = None, None
            for _ in range(length):
                embed = model.embed(input_x)
                out, (h, c) = model.lstm(embed, (h, c))
                logits = model.fc(out[:, -1, :])
                probs = torch.softmax(logits, dim=-1)
                next_idx = torch.multinomial(probs, 1).item()
                chars_out.append(idx_to_char[next_idx])
                input_x = torch.tensor([[next_idx]])
        return "".join(chars_out)

    # 6. Training loop
    num_epochs = 100
    for epoch in range(num_epochs):
        model.train()
        opt.zero_grad()
        logits = model(X)
        loss = loss_fn(logits, y.reshape(-1))
        loss.backward()
        opt.step()

        sample = ""
        if epoch % 10 == 0:
            sample = generate(model, "the")

        yield {
            "type": "progress",
            "epoch": epoch,
            "loss": loss.item(),
            "sample": sample,
        }

    # 7. บันทึกผลลัพธ์ (TODO: ปรับให้สร้าง samples.txt / loss_curve.png จริง)
    yield {
        "type": "done",
        "results": "static/dashboard/samples.txt",  # TODO: ต้องสร้างไฟล์จริง
    }
