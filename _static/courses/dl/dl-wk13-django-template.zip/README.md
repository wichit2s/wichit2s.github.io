# การบ้านสัปดาห์ที่ 13 — Text Generator Dashboard

สร้าง Django dashboard สำหรับสร้างข้อความด้วย Language Model (SSE streaming)

## วิธีรัน

```bash
uv sync
uv run manage.py runserver
```

เปิด http://127.0.0.1:8000/

## สิ่งที่นักศึกษาต้องทำ

1. **`dashboard/ml/train.py`** — implement `event_stream()` ให้สมบูรณ์
   (โหลดข้อความ, สร้าง vocabulary, LSTM, training loop, สร้าง sample text)
2. **`dashboard/views.py`** — เปลี่ยน `student_id` และ `student_name` เป็นของจริง

## ข้อมูล

- `data/corpus.txt` — ข้อความตัวอย่างภาษาอังกฤษ (55 คำ) พร้อมใช้แล้ว
- สามารถใช้ข้อความภาษาไทยหรืออังกฤษชุดอื่นได้ตามต้องการ (วางใน `data/corpus.txt`)

## หมายเหตุ

- Python 3.13 (กำหนดใน `pyproject.toml`)
- ส่งงานผ่าน branch `wk13`
