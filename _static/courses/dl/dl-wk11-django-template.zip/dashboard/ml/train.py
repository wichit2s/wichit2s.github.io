"""
การบ้านสัปดาห์ที่ 11 — Timeseries LSTM Dashboard

นักศึกษาต้องเขียนโค้ดในไฟล์นี้ให้สมบูรณ์ โดยต้องมีฟังก์ชัน:

    def event_stream():
        # generator ที่ yield dict ข้อมูลทีละ epoch แล้ว stream ผ่าน SSE

yield dict ที่มี key ต่อไปนี้ (แต่ละ epoch ระหว่างฝึกสอน):
    {
        "type": "progress",
        "epoch": <int>,
        "loss": <float>,
        "val_loss": <float>,
    }

และเมื่อฝึกสอนเสร็จ yield dict สุดท้าย:
    {
        "type": "done",
        "results": <ผลสรุป เช่น ลิงก์ไปยัง prediction_plot.png>,
    }

ข้อกำหนด:
    1. โหลดข้อมูลอนุกรมเวลา (จาก data/ เช่น temperature.csv)
    2. ใช้ sliding window แปลงข้อมูลเป็น supervised learning
    3. สร้างโมเดล LSTM (nn.LSTM + nn.Linear)
    4. Train/Val split (80/20)
    5. บันทึกกราฟ predicted vs actual เป็น PNG
       ที่ dashboard/static/dashboard/prediction_plot.png

ดูตัวอย่างโค้ดได้จาก slides wk11.html
"""

# TODO: เขียนโค้ดการบ้านตรงนี้


def event_stream():
    """
    generator สำหรับ stream ผลการฝึกสอนผ่าน SSE
    """
    # ----- ตัวอย่างโครงสร้าง (นักศึกษาต้องเขียนให้สมบูรณ์) -----

    import torch
    import torch.nn as nn

    # 1. โหลดข้อมูล
    #    ตัวอย่าง: ใช้ฟังก์ชัน sin + noise แทนไฟล์จริง
    #    นักศึกษาควรโหลดข้อมูลจาก data/temperature.csv หรือสร้างข้อมูลด้วยวิธีของตนเอง
    import math

    n = 2000
    x = torch.linspace(0, 20 * math.pi, n)
    values = torch.sin(x) + torch.randn(n) * 0.1
    values = values.unsqueeze(1)  # (n, 1)

    # 2. Sliding window → supervised learning
    window_size = 24

    def make_windows(data, win):
        X, y = [], []
        for i in range(win, len(data)):
            X.append(data[i - win : i])
            y.append(data[i])
        return torch.stack(X), torch.stack(y)

    X, y = make_windows(values, window_size)

    # 3. Train/Val split
    split = int(len(X) * 0.8)
    X_train, y_train = X[:split], y[:split]
    X_val, y_val = X[split:], y[split:]

    # 4. โมเดล LSTM
    class LSTMModel(nn.Module):
        def __init__(self, input_size=1, hidden_size=64, num_layers=2):
            super().__init__()
            self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
            self.fc = nn.Linear(hidden_size, 1)

        def forward(self, x):
            out, _ = self.lstm(x)
            return self.fc(out[:, -1, :])

    model = LSTMModel()
    loss_fn = nn.MSELoss()
    opt = torch.optim.Adam(model.parameters(), lr=0.001)

    # 5. Training loop
    num_epochs = 50
    for epoch in range(num_epochs):
        model.train()
        opt.zero_grad()
        y_hat = model(X_train)
        loss = loss_fn(y_hat, y_train)
        loss.backward()
        opt.step()

        # validation
        model.eval()
        with torch.no_grad():
            val_loss = loss_fn(model(X_val), y_val).item()
        model.train()

        if epoch % 5 == 0:
            yield {
                "type": "progress",
                "epoch": epoch,
                "loss": loss.item(),
                "val_loss": val_loss,
            }

    # 6. บันทึกผลลัพธ์ (TODO: ปรับให้สร้างกราฟจริง)
    yield {
        "type": "done",
        "results": "static/dashboard/prediction_plot.png",  # TODO: ต้องสร้างไฟล์จริง
    }
